<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Books extends Model
{
    use HasFactory;
    public $timestamps = false;

    public function publishers(){
        return $this->belongsTo(Publishers::class);
    }

    public function book_category(){
        return $this->hasMany(book_category::class);
    }
}
