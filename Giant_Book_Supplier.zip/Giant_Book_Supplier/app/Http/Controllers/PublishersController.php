<?php

namespace App\Http\Controllers;

use App\Models\Books;
use App\Models\Publishers;
use Illuminate\Http\Request;

class PublishersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Publishers  $publishers
     * @return \Illuminate\Http\Response
     */
    public function show(Publishers $publishers)
    {
        //
    }

    public function viewData($id)
    {
        $publishersdata = Books::find($id)::with('Publishers')
        ->join('publishers', 'books.publisher_id', '=', 'publishers.id')
        ->where('books.publisher_id', '=', $id)
        ->select('books.id as id', 'books.title as title', 'books.image as image', 'books.author as author', 'publishers.name as name', 'publishers.address as address', 'publishers.phone as phone', 'publishers.email as email', )
        ->get();

        return view('publisherdetail', compact('publishersdata', 'id'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Publishers  $publishers
     * @return \Illuminate\Http\Response
     */
    public function edit(Publishers $publishers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Publishers  $publishers
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Publishers $publishers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Publishers  $publishers
     * @return \Illuminate\Http\Response
     */
    public function destroy(Publishers $publishers)
    {
        //
    }
}
