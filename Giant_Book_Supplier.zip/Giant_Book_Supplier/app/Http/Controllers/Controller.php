<?php

namespace App\Http\Controllers;

use App\Models\Books;
use App\Models\Categories;
use App\Models\Publishers;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function mainMenu(){
        $booksData = Books::all();

        return view('home', ['books_data' => $booksData]);
    }

    public function publisherMenu(){
        $publisherData = Publishers::all();

        return view('publisher', ['publishers_data' => $publisherData]);
    }
}
