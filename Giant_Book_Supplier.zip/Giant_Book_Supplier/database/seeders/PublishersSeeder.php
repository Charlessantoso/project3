<?php

namespace Database\Seeders;

use App\Models\Publishers;
use Illuminate\Database\Seeder;

class PublishersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Publishers::query()->insert(
            [
                [
                    "id" => "1",
                    "name" => "Shueisha",
                    "address" => "1-2-1 Nihonbashi, Hongoku-cho, Chuo-ku, Tokyo 103-8345",
                    "phone" => "81323790332",
                    "email" => "webmaster@toyokeizai.co.jp",
                    "image" => "https://www.shueisha.co.jp/wp-content/uploads/2021/03/ogp.png"
                ],
                [
                    "id" => "2",
                    "name" => "Gramedia Pustaka Utama",
                    "address" => "Gedung Kompas Gramedia Blok 1 lt.5 Jl. Palmerah Barat No.29-37, Jakarta 10270, Indonesia",
                    "phone" => "02153650110",
                    "email" => "redaksi@gramediapustakautama.id",
                    "image" => "https://idwriters.com/wp-content/uploads/2014/04/logo-gm.jpg"
                ],
                [
                    "id" => "3",
                    "name" => "Bukunesia",
                    "address" => "Jl.Rajawali G. Elang 6 No 3 RT/RW 005/033, Drono, Sardonoharjo, Ngaglik, Sleman, D.I Yogyakarta 55581",
                    "phone" => "08112831577",
                    "email" => "admin@bukunesia.com",
                    "image" => "https://bukunesia.com/wp-content/uploads/2021/07/logo-bukunesia-150x150.png"
                ],
                [
                    "id" => "4",
                    "name" => "Penerbit Erlangga",
                    "address" => "Jl. H. Baping No. 100, Ciracas, Jakarta Timur, Indonesia",
                    "phone" => "081911500885",
                    "email" => "support@erlangga.co.id",
                    "image" => "https://upload.wikimedia.org/wikipedia/id/5/5b/Esis.jpg"
                ]
            ]
        );
    }
}
