<?php

namespace Database\Seeders;

use App\Models\Categories;
use Illuminate\Database\Seeder;

class CategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Categories::query()->insert(
            [
                [
                    "id" => "1",
                    "name" => "Comedy"
                ],
                [
                    "id" => "2",
                    "name" => "Romance"
                ],
                [
                    "id" => "3",
                    "name" => "Self-Improvement"
                ],
                [
                    "id" => "4",
                    "name" => "History",
                ]
            ]
        );
    }
}
