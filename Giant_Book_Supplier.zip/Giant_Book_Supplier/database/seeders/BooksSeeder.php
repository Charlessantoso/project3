<?php

namespace Database\Seeders;

use App\Models\Books;
use Illuminate\Database\Seeder;

class BooksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Books::query()->insert(
            [
                [
                    "id" => "1",
                    "publisher_id" => "2",
                    "title" => "Chinese Whispers",
                    "author" => "Ben Chu",
                    "year" => "2017",
                    "synopsis" => "Ben Chu membongkar berbagai mitos yang telah mendominasi pandangan kita tentang China.",
                    "image" => "https://gpu.id/data-gpu/images/uploads/book/9c44a21bf28807fb72a8309fd0d3a65c.jpg"
                ],
                [
                    "id" => "2",
                    "publisher_id" => "3",
                    "title" => "Atomic Habits: Perubahan Kecil yang memberikan hasil luar biasa",
                    "author" => "James Clear",
                    "year" => "2019",
                    "synopsis" => "Cara mudah dan terbukti untuk membentuk kebiasaan baik dan menghilangkan kebiasaan buruk",
                    "image" => "https://gpu.id/data-gpu/images/uploads/book/4816f7121fb8270f9b77cae8286ae593.jpg"
                ],
                [
                    "id" => "3",
                    "publisher_id" => "4",
                    "title" => "Love Your Life",
                    "author" => "Sophie Kinsella",
                    "year" => "2022",
                    "synopsis" => "Menurut Ava, cinta harus ditemukan di dunia nyata, bukannya pada filter aplikasi kencan yang mengatur tinggi cowok, pekerjaan, hobi, dan sebagainya.",
                    "image" => "https://gpu.id/data-gpu/images/img-book/93744/622183001.jpg"
                ],
                [
                    "id" => "4",
                    "publisher_id" => "1",
                    "title" => "Sebuah Seni untuk Bersikap Bodo Amat",
                    "author" => "Mark Manson",
                    "year" => "2016",
                    "synopsis" => "Sebuah Seni untuk Bersikap Bodo Amat adalah buku fenomenal yang menjadi panduan pengembangan diri saat ini. Isinya sangat relevan dan konteksual dengan fenomena-fenomena sosial zaman ini.",
                    "image" => "https://cdn.gramedia.com/uploads/items/Handy_Book_1.png"
                ]
            ]
        );
    }
}
