<?php

use App\Http\Controllers\BooksController;
use App\Http\Controllers\CategoriesController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\PublishersController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [Controller::class, 'mainMenu']);
Route::get('/category', function(){
    return redirect('/');
});
Route::get('/bookdetail', function(){
    return redirect('/');
});
Route::get('/bookdetail/{id}', [BooksController::class, 'viewData']);
Route::get('/category/{id}', [CategoriesController::class, 'viewData']);
Route::get('/publisher', [Controller::class, 'publisherMenu']);
Route::get('/publisher/{id}', [PublishersController::class, 'viewData']);
Route::get('/contact', function(){
    return view('contact');
});