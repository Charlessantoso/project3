

<?php $__env->startSection('document_title', 'home'); ?>
<?php $__env->startSection('body'); ?>

    <div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
        <div style="margin-bottom: 10px">
            <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px">
                <h2>Contact</h2>
            </div>
        </div>
        <!-- Content buku -->
        <h3>Store Address :</h3>
        <p>
            <br>Jalan Pembangunan Baru Raya,
            <br>Kompleks Pertokoan Emerald Blok III/12
            <br>Bintaro, Tangerang Selatan
            <br>Indonesia
        </p>
        <p>
            <h3>Open Daily :</h3>
            <br>08.00 - 20.00
        </p>
        <p>
            <h3>Contact :</h3>
            <br>Phone: 021-08899776655
            <br>Email: happybookstore@happy.com
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\BINUS\Semester 5\UTS Semester 5\Web Programming\2440016533-Charles Santoso_UTS_Operating_Systems\2440016533\resources\views/contact.blade.php ENDPATH**/ ?>