
<?php $__env->startSection('document_title', 'home'); ?>
<?php $__env->startSection('body'); ?>

    <div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
        <div style="margin-bottom: 10px">
            <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px">
                <?php $__currentLoopData = $booksdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h2><?php echo e($book->categoryName); ?></h2>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="d-flex flex-wrap justify-content-center">
            <!-- Content buku -->
            <?php $__currentLoopData = $booksdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e($book->image); ?>" class="card-img-top" alt="..." height="350">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($book->title); ?></h5>
                        <div class="mt-auto">
                            <p class="card-text">by<br><?php echo e($book->author); ?></p>
                            <a href="/bookdetail/<?php echo e($book->bookid); ?>" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\BINUS\Semester 5\UTS Semester 5\Web Programming\2440016533_Charles_Santoso\2440016533\resources\views/category.blade.php ENDPATH**/ ?>