
<?php $__env->startSection('document_title', 'home'); ?>
<?php $__env->startSection('body'); ?>

    <div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
        <div style="margin-bottom: 10px">
            <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px">
                <h2>Publisher List</h2>
            </div>
        </div>

        <div class="d-flex flex-wrap justify-content-center">
            <!-- Content buku -->
            <?php $__currentLoopData = $publishers_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publishersdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e($publishersdata->image); ?>" class="card-img-top" alt="..." height="350">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($publishersdata->name); ?></h5>
                        <p class="card-text"><?php echo e($publishersdata->address); ?></p>
                        <div class="mt-auto">
                            <a href="/publisher/<?php echo e($publishersdata->id); ?>" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('Component.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\BINUS\Semester 5\UTS Semester 5\Web Programming\2440016533-Charles Santoso_UTS_Web_Programming\2440016533\resources\views/publisher.blade.php ENDPATH**/ ?>