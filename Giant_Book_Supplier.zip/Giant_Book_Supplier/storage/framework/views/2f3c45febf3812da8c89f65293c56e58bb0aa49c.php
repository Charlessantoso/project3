<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('document_title'); ?></title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>
<body>

    <div  class="d-flex flex-wrap justify-content-center" style="background-color:#c29b02; color:white; padding: 20px">
    <h1>Giant Book Supplier</h1>
    </div>

    <!-- Navbar -->
    <div class="d-flex flex-wrap justify-content-center">
        <nav class="navbar navbar-expand-lg color-blue">
                <div class="container-fluid">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/"  style="color:rgb(28, 152, 246);">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" style="color:rgb(28, 152, 246);" data-bs-toggle="dropdown" aria-expanded="false">
                            Category
                            </a>
                            <ul class="dropdown-menu">
                            <li><a class="dropdown-item" style="color:black;" href="/category/1">Comedy</a></li>
                            <li><a class="dropdown-item" style="color:black;" href="/category/2">Romance</a></li>
                            <li><a class="dropdown-item" style="color:black;" href="/category/3">Self-Improvement</a></li>
                            <li><a class="dropdown-item" style="color:black;" href="/category/4">History</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" style="color:rgb(28, 152, 246);" href="/publisher">Publisher</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" style="color:rgb(28, 152, 246);" href="/contact">Contact</a>
                        </li>
                        </ul>
                    </div>
                </div>
        </nav>   
    </div>
    <?php echo $__env->yieldContent('body'); ?>


    <!-- footer -->
    <footer>
        <div  class="d-flex flex-wrap justify-content-center align-items-end" style="background-color:#0086f3; color:white; padding: 12px ;font-size: 12px; margin-top:0px">
            <h6>© Happy Book Store 2022</h6>
        </div>
    </footer>


    <!-- JavaScript Bundle with Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\Kuliah\BINUS\Semester 5\UTS Semester 5\Web Programming\2440016533_Charles_Santoso\2440016533\resources\views/Component/navbar.blade.php ENDPATH**/ ?>