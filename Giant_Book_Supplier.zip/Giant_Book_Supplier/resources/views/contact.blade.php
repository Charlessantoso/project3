
@extends('Component.navbar')
@section('document_title', 'home')
@section('body')

    <div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
        <div style="margin-bottom: 10px">
            <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px">
                <h2>Contact</h2>
            </div>
        </div>
        <!-- Content buku -->
        <h3>Store Address :</h3>
        <p>
            <br>Jalan Pembangunan Baru Raya,
            <br>Kompleks Pertokoan Emerald Blok III/12
            <br>Bintaro, Tangerang Selatan
            <br>Indonesia
        </p>
        <p>
            <h3>Open Daily :</h3>
            <br>08.00 - 20.00
        </p>
        <p>
            <h3>Contact :</h3>
            <br>Phone: 021-08899776655
            <br>Email: happybookstore@happy.com
        </p>
    </div>
@endsection