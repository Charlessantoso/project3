@extends('Component.navbar')
@section('document_title', 'home')
@section('body')

    <div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
        <div style="margin-bottom: 10px">
            <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px">
                <h2>Book Detail</h2>
            </div>
        </div>

        <!-- Book details-->
        @foreach ($booksdata as $booksdata)
            

        <div class="card-group d-flex flex-wrap justify-content-center">
            <div class="card" style="width: 18rem;">
                <img src="{{$booksdata->image}}" class="card-img-top" alt="...">
                <div class="card-body">
                    <li class="list-group-item"><b>Title:</b> {{$booksdata->title}}</li>
                    <li class="list-group-item"><b>Author:</b> {{$booksdata->author}}</li>
                    <li class="list-group-item"><b>Publisher:</b> {{$booksdata->name}}</li>
                    <li class="list-group-item"><b>Year:</b> {{$booksdata->year}}</li>
                    <li class="list-group-item"><b>Synopsis:</b> </li>
                    <p class="card-text">{{$booksdata->synopsis}}</p>
                </div>
            </div>
        </div>

        @endforeach

    </div>
    @endsection