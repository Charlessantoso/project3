@extends('Component.navbar')
@section('document_title', 'home')
@section('body')

    <div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
        <div style="margin-bottom: 10px">
            @foreach ($publishersdata as $publisherdata)
                <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px;">
                    <ul>
                    <ol><h2>{{$publisherdata->name}}</h2></ol>
                    <ol><h2>{{$publisherdata->address}}</h2></ol>
                    <ol><h2>{{$publisherdata->phone}}</h2></ol>
                    <ol><h2>{{$publisherdata->email}}</h2></ol>
                    </ul>
                </div>
            @endforeach
        </div>

        <div class="d-flex flex-wrap justify-content-center">
            <!-- Content buku -->
            @foreach ($publishersdata as $publishersdata)
                <div class="card" style="width: 18rem;">
                    <img src="{{$publishersdata->image}}" class="card-img-top" alt="..." height="350">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">{{$publishersdata->title}}</h5>
                        <div class="mt-auto">
                            <p class="card-text">by<br>{{$publishersdata->author}}</p>
                            <a href="/bookdetail/{{$publishersdata->id}}" class="btn btn-primary">Detail</a>
                        </div>
                    </div>
                </div> 
            @endforeach
        </div>
    </div>
 @endsection