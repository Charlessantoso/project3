
@extends('Component.navbar')
@section('document_title', 'home')
@section('body')

<div style="padding-left:11rem; padding-right:11rem; padding-bottom:11rem; padding-top:2rem">
    <div style="margin-bottom: 10px">
        <div  class="d-flex flex-wrap" style="background-color:grey; color:white; padding: 5px">
            <h2>Book List</h2>
        </div>
    </div>
    <div class="d-flex flex-wrap justify-content-center">
        <!-- Content buku -->
        @foreach ($books_data as $book)
            <div class="card" style="width: 18rem;">
                <img src="{{$book->image}}" class="card-img-top" alt="..." height="350">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{$book->title}}</h5>
                    <div class="mt-auto">
                        <p class="card-text">by<br>{{$book->author}}</p>
                        <a href="/bookdetail/{{$book->id}}" class="btn btn-primary">Detail</a>
                    </div>
                </div>
            </div> 
        @endforeach
    </div>
</div>
@endsection